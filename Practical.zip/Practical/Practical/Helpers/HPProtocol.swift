//
//  HPProtocol.swift
//  Practical
//
//  Created by PC on 27/11/19.
//  Copyright © 2019 PC. All rights reserved.
//

import Foundation

protocol reloadCellCallBack{
    func reloadCellData(index:Int)
}



