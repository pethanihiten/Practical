//
//  Constants.swift
//  Heedful
//
//  Created by Hiten on 28/6/18.
//  Copyright © 2018 Hiten. All rights reserved.



import Foundation


let BASE_URL = "http://5.153.252.253/arsenal_api/index.php/v2/"


let login = "Login"
